
import Navigation from "./Navigation";


function App() {
  return (
    <>
    <Navigation></Navigation>
   
    </>
  );
}

export default App;
